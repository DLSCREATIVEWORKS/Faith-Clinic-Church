/* Newsletter signup: sends to MailerLite form "LifeBook | Website Form | Book Updates"
   (group "LifeBook | Book Updates"). Readers confirm by email (double opt-in). */
(function () {
  var form = document.getElementById('lb-subscribe');
  if (!form) return;
  var msg = document.getElementById('lb-subscribe-msg');
  var started = Date.now();
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var email = form.email.value.trim();
    if (form.website.value || Date.now() - started < 2000) { form.reset(); msg.textContent = 'Thank you! Check your email to confirm.'; return; }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { msg.textContent = 'Please enter a valid email address.'; return; }
    msg.textContent = 'Sending…';
    var body = new FormData();
    body.append('fields[email]', email);
    body.append('ml-submit', '1');
    body.append('anticsrf', 'true');
    fetch(form.getAttribute('data-endpoint'), { method: 'POST', body: body })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j && j.success) { form.reset(); msg.textContent = 'Thank you! Check your email and click the link to confirm your subscription.'; }
        else { msg.textContent = 'That did not go through. Please check your email address and try again.'; }
      })
      .catch(function () { msg.textContent = 'We could not sign you up right now. Please try again later.'; });
  });
})();
